package chessgame;

public class Pawn extends ChessPiece {

    public Pawn(Color c) {
        super(c);
    }

    @Override
    public String toString() {
        return (color == Color.black) ? "p" : "P";
    }

    @Override
    public boolean legalMove(String movStr, ChessPiece[][] board) {

        int srcRow = ChessUtil.getDstRow(movStr);
        int srcCol = ChessUtil.getSrcCol(movStr);
        int dstRow = ChessUtil.getDstRow(movStr);
        int dstCol = ChessUtil.getDstCol(movStr);
        if (movStr.matches("^[abcdefgh12345678-]$") == true) {
            return false;
        }
        return true;
    }
}
