package chessgame;

public class ChessUtil {
	// get the source square row from the move string
	public static int getSrcRow(String movStr) {
		return getRow(movStr.charAt(1));
	}

	// get the source square column from the move string
	public static int getSrcCol(String movStr) {
		return getCol(movStr.charAt(0));
	}
	
	// get the destination square row from the move string
	public static int getDstRow(String movStr) {
		return getRow(movStr.charAt(3));
	}
	
	// get the destination square column from the move string
	public static int getDstCol(String movStr) {
		return getCol(movStr.charAt(2));
	}

	// pass in a rank, get back a row
	public static int getRow(char rank) {
		return 8 - Character.getNumericValue(rank);
	}

	// pass in a file, get back a column
	public static int getCol(char file) {
		return (file - 'a');
	}

}