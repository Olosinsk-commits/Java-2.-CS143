package chessgame;

public class ChessBoard {

    private ChessPiece[][] board = new ChessPiece[8][8];

    public ChessBoard() {
        // initialize the back row 
        // of the black pieces
        board[0][0] = new Rook(Color.black);
        board[0][1] = new Knight(Color.black);
        board[0][2] = new Bishop(Color.black);
        board[0][3] = new Queen(Color.black);
        board[0][4] = new King(Color.black);
        board[0][5] = new Bishop(Color.black);
        board[0][6] = new Knight(Color.black);
        board[0][7] = new Rook(Color.black);

        // initialize the front row (the pawns) 
        // of the black pieces 
        for (int col = 0; col < 8; col++) {
            board[1][col] = new Pawn(Color.black);
        }

        // initialize the four empty rows in the middle
        for (int row = 2; row < 6; row++) {
            for (int col = 0; col < 8; col++) {
                board[row][col] = null;
            }
        }

        // initialize the front row (the pawns) 
        // of the white pieces
        for (int col = 0; col < 8; col++) {
            board[6][col] = new Pawn(Color.white);
        }

        // initialize the back row 
        // of the white pieces
        board[7][0] = new Rook(Color.white);
        board[7][1] = new Knight(Color.white);
        board[7][2] = new Bishop(Color.white);
        board[7][3] = new Queen(Color.white);
        board[7][4] = new King(Color.white);
        board[7][5] = new Bishop(Color.white);
        board[7][6] = new Knight(Color.white);
        board[7][7] = new Rook(Color.white);
    }

    public boolean move(String movStr) {
        // extract the source row/column from 
        // the move string 
        int srcRow = ChessUtil.getSrcRow(movStr);
        int srcCol = ChessUtil.getSrcCol(movStr);

        // if the source square is empty, bad move
        if (board[srcRow][srcCol] == null) {
            return false;
        }

        // extract the destination row/column from
        // the move string
        int dstRow = ChessUtil.getDstRow(movStr);
        int dstCol = ChessUtil.getDstCol(movStr);

        // if the chess piece says it's an illegal 
        // move, return false
        if (board[srcRow][srcCol].legalMove(movStr, board) == false) {
            return false;
        }

        // otherwise, make the move on the chess board
        board[dstRow][dstCol] = board[srcRow][srcCol];
        board[srcRow][srcCol] = null;

        return true;
    }

    // output an 8x8 representation of the 
    // current state of the chess board
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                if (board[row][col] == null) {
                    sb.append(".");
                } else {
                    sb.append(board[row][col]);
                }
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    public ChessPiece getPiece(Integer x, Integer y) {
        return board[x][y];
    }
}
