package chessgame;

public abstract class ChessPiece {
	protected Color color;

	public ChessPiece(Color c) {
		color = c;
	}

public abstract boolean legalMove(String movStr, ChessPiece[][] board);

}