package chessgame;

import java.util.Scanner;

public class Game {
	public static void main(String[] args) {
		// initialize the chess board, and print it out
		ChessBoard bd = new ChessBoard();
		System.out.println(bd);

		Scanner keyboard = new Scanner(System.in);

		// prompt the user for a move
		System.out.println("Enter move");

		// get a move and test for end of game
		String mv;
		while (!(mv = keyboard.next()).equals("quit")) {
			// make the move on the board
			bd.move(mv);
			
			// print out the board
			System.out.println(bd);
			
			// prompt the user for another move
			System.out.println("Enter move");
		}
	}
}