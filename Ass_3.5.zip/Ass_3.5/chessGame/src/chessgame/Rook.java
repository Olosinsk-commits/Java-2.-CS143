package chessgame;

public class Rook extends ChessPiece {

    public Rook(Color c) {
        super(c);
    }

    @Override
    public String toString() {
        return (color == Color.black) ? "r" : "R";
    }

    @Override
    public boolean legalMove(String movStr, ChessPiece[][] board) {

        int srcRow = ChessUtil.getDstRow(movStr);
        int srcCol = ChessUtil.getSrcCol(movStr);
        int dstRow = ChessUtil.getDstRow(movStr);
        int dstCol = ChessUtil.getDstCol(movStr);
        if (movStr.matches("^[abcdefgh12345678-]$") == true) {
            return false;
        }
        if ((srcRow == dstRow) && (srcCol == dstCol)) {
            return false;
        }
        if ((srcRow != dstRow) && (srcCol != dstCol)) {
            return false;
        }

        ChessPiece per = board[srcRow][srcCol];

        if ((per != null) && (per.color == this.color)) {
            return false;
        }

        Integer stepBeforeX;
        Integer stepBeforeY;
        if (dstRow > srcRow) {
            stepBeforeX = dstRow - 1;
            stepBeforeY = dstCol;
        } else if (srcRow > dstRow) {
            stepBeforeX = dstRow + 1;
            stepBeforeY = dstCol;
        } else if (dstCol > srcCol) {
            stepBeforeX = dstRow;
            stepBeforeY = dstCol - 1;
        } else if (srcCol > dstCol) {
            stepBeforeX = dstRow;
            stepBeforeY = dstCol + 1;
        } else {
            stepBeforeX = dstRow;
            stepBeforeY = dstCol;
        }
        ChessPiece pieceStepBefore = board[stepBeforeX][stepBeforeY];
        if (pieceStepBefore == null) {
            return true;
        }
        return true;
    }
}
