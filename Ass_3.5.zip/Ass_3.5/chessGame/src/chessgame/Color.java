package chessgame;

public enum Color {
	black, white
}