package chessgame;

public class King extends ChessPiece {
	public King(Color c) {
		super(c);
	}

	@Override
	public String toString() {
		return (color == Color.black) ? "k" : "K";
	}

	@Override
	public boolean legalMove(String movStr, ChessPiece[][] board) {
		return true;
	}

}